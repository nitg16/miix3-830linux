/* This file is auto generated, version 201705282131 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201705282131 SMP Fri Jun 2 00:21:31 +08 2017"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "builder"
#define LINUX_COMPILER "gcc version 6.3.0 20170406 (Ubuntu 6.3.0-12ubuntu2) "
